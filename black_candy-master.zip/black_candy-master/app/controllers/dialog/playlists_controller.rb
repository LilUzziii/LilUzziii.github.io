# frozen_string_literal: true

class Dialog::PlaylistsController < PlaylistsController
  layout 'dialog'
end

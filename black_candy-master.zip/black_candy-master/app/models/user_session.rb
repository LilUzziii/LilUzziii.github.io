# frozen_string_literal: true

class UserSession < Authlogic::Session::Base
end
